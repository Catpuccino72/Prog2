root_dir=$(pwd)


echo ___________________
echo        TASK1
javac -cp $root_dir/task1/ $root_dir/task1/Main.java && java -cp $root_dir/task1/ $root_dir/task1/Main.java
echo ___________________
echo

echo ___________________
echo        TASK2
javac -cp $root_dir $root_dir/de/uni_hannover/task2/Main.java && java -cp $root_dir $root_dir/de/uni_hannover/task2/Main.java
echo ___________________

echo ___________________
echo        TASK3
javac -cp $root_dir/task3/ $root_dir/task3/aufgabe3/DebugMain.java && java -cp $root_dir/task3/ $root_dir/task3/aufgabe3/DebugMain.java
echo ___________________





















































































echo ich würde so etwas ja nicht ausführen
